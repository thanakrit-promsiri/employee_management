<?php

/* * translate by mr.v automatic
 * www.okvee.net
 */

$lang['ftp_no_connection'] = "ไม่พบ ID การเชื่อมต่อ.  โปรดตรวจให้แน่ใจว่าทำการเชื่อมต่อแล้วก่อนทำการใดๆ.";
$lang['ftp_unable_to_connect'] = "ไม่สามารถเชื่อมต่อ FTP server ของคุณตามข้อมูลที่ให้มา.";
$lang['ftp_unable_to_login'] = "ไม่สามารถเข้าสู่ระบบ your FTP server.  โปรดตรวจสอบ username และ password.";
$lang['ftp_unable_to_makdir'] = "ไม่สามารถสร้างไดเร็คทอรี่ตามที่กำหนด.";
$lang['ftp_unable_to_changedir'] = "ไม่สามารถเปลี่ยนไดเร็คทอรี่.";
$lang['ftp_unable_to_chmod'] = "ไม่สามารถกำหนดการอนุญาตของไฟล์.  โปรดตรวจสอบพาธ.  Note: This feature is only available in PHP 5 or higher.";
$lang['ftp_unable_to_upload'] = "ไม่สามารถอัปโหลดไฟล์ที่กำหนดได้.  โปรดตรวจสอบพาธ.";
$lang['ftp_unable_to_download'] = "ไม่สามารถดาวน์โหลดไฟล์ที่ระบุ. โปรดตรวจสอบพาธ.";
$lang['ftp_no_source_file'] = "ไม่สามารถหาตำแหน่งไฟล์ต้นฉบับ.  โปรดตรวจสอบพาธ.";
$lang['ftp_unable_to_rename'] = "ไม่สามารถเปลี่ยนชื่อไฟล์.";
$lang['ftp_unable_to_delete'] = "ไม่สามารถลบไฟล์.";
$lang['ftp_unable_to_move'] = "ไม่สามารถย้ายไฟล์.  โปรดแน่ใจว่าไดเร็คทอรี่เป้าหมายมีอยู่.";


/* End of file ftp_lang.php */
/* Location: ./system/language/english/ftp_lang.php */