<?php
/**translate by mr.v automatic
 *www.okvee.net
 */

$lang['upload_userfile_not_set'] = "ไม่พบตัวแปรการโพสต์ที่เรียกว่า userfile.";
$lang['upload_file_exceeds_limit'] = "ไฟล์ที่อัพโหลดเกินขนาดสูงสุดที่อนุญาตในไฟล์ตั้งค่า PHP ของคุณ.";
$lang['upload_file_exceeds_form_limit'] = "ไฟล์ที่อัพโหลดมีขนาดเกินอนุญาต.";
$lang['upload_file_partial'] = "ไฟล์ที่ถูกอัพโหลดเพียงบางส่วนเท่านั้น.";
$lang['upload_no_temp_directory'] = "โฟลเดอร์ชั่วคราวหายไป.";
$lang['upload_unable_to_write_file'] = "ไฟล์ไม่สามารถเขียนไปยังดิสก์.";
$lang['upload_stopped_by_extension'] = "อัปโหลดไฟล์ได้หยุดโดยนามสกุล.";
$lang['upload_no_file_selected'] = "คุณไม่ได้เลือกไฟล์ที่จะอัพโหลด.";
$lang['upload_invalid_filetype'] = "ประเภทไฟล์ที่คุณพยายามจะอัพโหลดนั้นไม่อนุญาต.";
$lang['upload_invalid_filesize'] = "แฟ้มที่คุณพยายามอัปโหลดมีขนาดใหญ่กว่าขนาดที่อนุญาต.";
$lang['upload_invalid_dimensions'] = "ภาพที่คุณพยายามอัปโหลดเกินความสูงหรือความกว้างสูงสุด.";
$lang['upload_destination_error'] = "พบปัญหาในขณะที่พยายามจะย้ายไฟล์ที่อัพโหลดไปยังปลายทาง.";
$lang['upload_no_filepath'] = "ตำแหน่งอัปโหลดไม่ถูกต้อง.";
$lang['upload_no_file_types'] = "คุณไม่ได้ระบุประเภทไฟล์ที่ได้รับอนุญาต.";
$lang['upload_bad_filename'] = "ชื่อไฟล์ที่คุณส่งมีอยู่แล้วบนเซิร์ฟเวอร์.";
$lang['upload_not_writable'] = "โฟลเดอร์ปลายทางอัพโหลดไม่อนุญาตให้อัปโหลด.";


/* End of file upload_lang.php */
/* Location: ./system/language/english/upload_lang.php */