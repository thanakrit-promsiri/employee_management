<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['action_update'] = "แก้ไข";
$lang['action_insert'] = "เพิ่ม";
