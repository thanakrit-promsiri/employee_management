<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['sys_error'] = "การทำงานของระบบผิดพลาด";
$lang['save_error'] = "การทำงานของคุณไม่สำเร็จ เนื่องจากการทำงานของระบบผิดพลาด <br>กรุณาลองใหม่อีกครั้ง หรือติดต่อผู้ดูแลระบบ";
$lang['page_not_found'] = "ไม่พบหน้าที่คุณร้องขอ";
